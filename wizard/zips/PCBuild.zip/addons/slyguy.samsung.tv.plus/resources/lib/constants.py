DATA_URL = 'https://i.mjh.nz/SamsungTVPlus/app.json.gz'
EPG_URL = 'https://i.mjh.nz/SamsungTVPlus/{code}.xml.gz'
ALL = 'all'
MY_CHANNELS = 'my_channels'

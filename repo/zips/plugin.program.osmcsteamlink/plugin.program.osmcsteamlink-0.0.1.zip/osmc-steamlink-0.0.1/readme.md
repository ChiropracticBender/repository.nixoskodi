1st version tested on kodi 18 with OSMC  
needed : steamlink from here : https://steamcommunity.com/app/353380/discussions/0/1743353164093954254/  
Shell scripts are from https://github.com/wackerl91/luna stripped with just
 we need.

